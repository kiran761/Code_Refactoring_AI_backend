# Nodejs-Mongodb-CRUD
-In this repository, I have created CRUD operation sites using Nodejs as backend with Nosql database.

# what you need to use
-You have to use nodejs, expressjs, mongodb, mongoose, ejs, css etc.
Generally, here we are just letting the admin add, delete or update the user i.e to perform CRUD operation using NoSql.

# Level
-Basic
-It is very simple and important projects of nodejs and mongodb.
So you can add this app in your resume as well.

# How can i used this project in my application
- just go to code button and download the zip file 
- after that extract that zip file to some folder where u want your react files
- then go to that folder & go to package.json and download all the dependencies list that is in the dependencie key
- before downloading dependencie you have to download npm first
- thats it you have successfully imported my projects and executed in your computer
 Why i need to download further stuffs?
=because nodemodules folder can't be uploaded in github and as you know it stores all the dependencies inside .
