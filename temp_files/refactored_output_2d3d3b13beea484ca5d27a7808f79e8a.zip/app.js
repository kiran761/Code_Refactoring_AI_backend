import express from 'express';
import mongoose from 'mongoose';
import User from './models/user.js';

const app = express();

const dbURI = "paste here your mongodb uri that can be get form connect button";

(async () => {
  try {
    await mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log("Database-connected");
    app.listen(8080);
  } catch (err) {
    console.error(err);
  }
})();

app.set('view engine', 'ejs');

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.redirect('/users');
});

app.get('/users', async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.render('index', { users, title: 'Home' });
  } catch (err) {
    console.error(err);
  }
});

app.get('/about', (req, res) => {
  res.render('about', { title: 'About' });
});

app.get('/user/create', (req, res) => {
  res.render('adduser', { title: 'Add-User' });
});

app.get('/users/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    res.render('details', { user, action: 'edit', title: 'User Details' });
  } catch (err) {
    console.error(err);
  }
});

app.get('/edit/:name/:action', async (req, res) => {
  try {
    const user = await User.findOne({ name: req.params.name });
    res.render('edit', { user, title: 'Edit-User' });
  } catch (err) {
    console.error(err);
  }
});

app.post('/user/create', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.redirect('/users');
  } catch (err) {
    console.error(err);
  }
});

app.post('/edit/:id', async (req, res) => {
  try {
    await User.updateOne({ _id: req.params.id }, req.body);
    res.redirect('/users');
    console.log("Users profile Updated");
  } catch (err) {
    console.error(err);
  }
});

app.post('/users/:name', async (req, res) => {
  try {
    await User.deleteOne({ name: req.params.name });
    res.redirect('/users');
  } catch (err) {
    console.error(err);
  }
});

app.use((req, res) => {
  res.render('404', { title: 'NotFound' });
});